/*
  PID.h - PID control library - description
  Copyright (c) 2020 James T. Teasdale.  All right reserved.
*/

// ensure this library description is only included once
#ifndef PID_h
#define PID_h

#if (ARDUINO >= 100)
    #include "Arduino.h"
#else 
    #include "WProgram.h"
#endif

// library interface description
class PID
{

  // user-accessible "public" interface
  public:

      // Set point
      double d_setPoint;

      // Gains
      double d_Kp;
      double d_Ki;
      double d_Kd;

      // Constructor
      PID(double setPoint, double setPointRange, double Kp, double Ki, double Kd);

      // Methods
      void setSetPointRange(double setPointRange);
      void setIndicator(int indicatorPin);
      bool isAtSetPoint(int value);
      double run(double value);
      double PWM_run(int PWN_outputPin, double value);

  // library-accessible "private" interface
  private:
      // Pins
      int int_indicatorPin = -1;

      // Set point
      double d_setPointRange;

      // PID memories
      double _lastError;
      double _lastArea; 
      unsigned long _lastTime;

      // Methods
      double integrate(double thisValue, unsigned long thisTime);
      double differentiate(double thisValue, unsigned long thisTime);

};

#endif