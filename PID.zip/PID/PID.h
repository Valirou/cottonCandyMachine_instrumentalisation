/*
  PID.h - PID control library - description
  Copyright (c) 2020 James T. Teasdale.  All right reserved.
*/

// ensure this library description is only included once
#ifndef PID_h
#define PID_h

#include "Arduino.h"

// library interface description
class PID
{

  // user-accessible "public" interface
  public:

      // Set point
      double d_setPoint;

      // Gains
      double d_Kp;
      double d_Ki;
      double d_Kd;

      // Methods
      PID(int analog_inputPin, int PWM_outputPin, double setPoint, double setPointRange, double Kp, double Ki, double Kd, int maxOutput = 255, int minOutput = 0);
      void setSetPointRange(double setPointRange);
      void setIndicator(int indicatorPin);
      bool isAtSetPoint();
      int run();

  // library-accessible "private" interface
  private:
      // Pins
      int int_analog_inputPin;
      int int_PWM_outputPin;
      int int_indicatorPin = -1;

      // Set point
      double d_setPointRange;

      // Output limitations
      int int_maxOutput;
      int int_minOutput;

      // PID memories
      double _lastError;
      double _lastArea; 
      unsigned long _lastTime;

      // Methods
      double integrate(double thisValue, unsigned long thisTime);
      double differentiate(double thisValue, unsigned long thisTime);

};

#endif