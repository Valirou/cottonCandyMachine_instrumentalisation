/*
  PID.h - PID control library - description
  Copyright (c) 2020 James T. Teasdale.  All right reserved.
*/

// include this library's description file
#include "Arduino.h"
#include "PID.h"

// Constructor /////////////////////////////////////////////////////////////////

PID::PID(int analog_inputPin, int PWM_outputPin, double setPoint, double setPointRange, double Kp, double Ki, double Kd, int maxOutput = 255, int minOutput = 0) {
    // Asserts
    if (maxOutput > 255) {
        maxOutput = 255;
    }
    if (minOutput < 0) {
        minOutput = 0;
    }
    if (minOutput > maxOutput) {
        minOutput = maxOutput;
    }
    
    // Pins
    int_analog_inputPin = analog_inputPin;
    int_PWM_outputPin = PWM_outputPin;

    pinMode(int_analog_inputPin, INPUT);
    pinMode(int_PWM_outputPin, OUTPUT);

    // set point
    d_setPoint = setPoint;

    // Gains
    d_Kp = Kp;
    d_Ki = Ki;
    d_Kd = Kd;

    // Output limitations
    int_maxOutput = maxOutput;
    int_minOutput = minOutput;
}

// Public Methods //////////////////////////////////////////////////////////////

void PID::setSetPointRange(double setPointRange) {
    // Asserts
    if (setPointRange < 0) {
        setPointRange = 0;
    }
    else if (setPointRange > 1) {
        setPointRange = 1;
    }

    d_setPointRange = setPointRange;
}

void PID::setIndicator(int indicatorPin) {
    int_indicatorPin = indicatorPin;
    pinMode(int_indicatorPin, OUTPUT);
}

bool PID::isAtSetPoint() {
    // Read sensor on analog input pin
    int value = analogRead(int_analog_inputPin);

    // Get set point range limits
    double minValue = d_setPoint * (1 - d_setPointRange);
    double maxValue = d_setPoint * (1 + d_setPointRange);

    // Verify that the value is included in the range limits
    bool isSetPointReached = (minValue <= value) && (value <= maxValue);

    if (int_indicatorPin != -1) {
        if (isSetPointReached) {
            digitalWrite(int_indicatorPin, HIGH);
        }
        else {
            digitalWrite(int_indicatorPin, LOW);
        }
    }

    return isSetPointReached;
}

int PID::run() {
    // Read sensor on analog input pin
    int value = int(analogRead(int_analog_inputPin));

    // Store actual time
    unsigned long thisTime = millis();

    // Assert
    if (_lastTime > thisTime) {
        thisTime = _lastTime;
    }

    // Get signal error
    long error = d_setPoint - value;

    // Calculate signal correction
    double P_Gain = error * d_Kp;
    double I_Gain = integrate(error, thisTime) * d_Ki;
    double D_Gain = differentiate(error, thisTime) * d_Kd;
    double correction = P_Gain + I_Gain + D_Gain;

    // Check output limitations
    if (correction > int_maxOutput) {
        correction = int_maxOutput;
    }
    else if (correction < int_minOutput) {
        correction = int_minOutput;
    }

    // Store error and processing time
    _lastError = correction;
    _lastTime = thisTime;

    // Apply correction on PWM output pin
    analogWrite(int_PWM_outputPin, correction);

    return value;
}

// Private Methods /////////////////////////////////////////////////////////////

double PID::integrate(double thisValue, unsigned long thisTime) {
    // Asserts
    if (_lastTime > thisTime) {
        thisTime = _lastTime;
    }

    // Integrate by approximating the area under the curve with the erea of a trapeze since the time between processing is REALLY short
    double thisArea = (thisValue + _lastError) * (thisTime - _lastTime) / 2.0;
    if (isnan(thisArea)) {
        thisArea = 0;
    }

    // Calculate the total area
    double totalArea = _lastArea + thisArea;

    // Store new total area for next integration
    _lastArea = totalArea;
    _lastError = thisValue;

    return totalArea;
}

double PID::differentiate(double thisValue, unsigned long thisTime) {
    // Asserts
    if (_lastTime > thisTime) {
        thisTime = _lastTime;
    }

    // Calculate the instantaneous curve slope
    double slope = (thisValue - _lastError) / (thisTime - _lastTime);
    if (isnan(slope)) {
        slope = 0;
    }

    // Differentiate by approximating the curve with a line since the time between processing is REALLY short
    return slope;
}